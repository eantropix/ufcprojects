#include <iostream>
#include <algorithm>

// Reutilizando as classes e o estilo do projeto Archive
#include "header/Vector3.h"
#include "header/Ray.h"
#include "header/Sphere.h"
#include "header/Color.h"
#include "header/HitRecord.h"
#include "header/Material.h"
#include "header/Framebuffer.h"
#include "header/Display.h"

int main() {
    // 1) Defina uma janela através da qual o pintor verá a esfera 
    float wJanela = 60.0f;
    float hJanela = 60.0f;
    float dJanela = 30.0f;

    // 2) O olho do pintor está na origem do sistema de coordenadas (0,0,0)
    Vector3 origin(0.0f, 0.0f, 0.0f);

    // 3) O raio da esfera deve ser armazenado na variável rEsfera
    float rEsfera = 40.0f;

    // 4) O centro da esfera deve estar sobre o eixo z com coordenada z < - (dJanela + rEsfera)
    Vector3 centerEsfera(0.0f, 0.0f, -100.0f);

    // 5) A cor da esfera deve ser esfColor = 255, 0, 0
    Color esfColor(1.0f, 0.0f, 0.0f);

    // 6) A cor de background deve ser cinza bgColor = 100, 100, 100
    Color bgColor(100.0f/255.0f, 100.0f/255.0f, 100.0f/255.0f);

    // 7) Defina o número de colunas nCol e o número de linhas nLin
    int nCol = 800;
    int nLin = 800;

    // As dimensões dos retângulos da tela de mosquito
    float Dx = wJanela / (float)nCol;
    float Dy = hJanela / (float)nLin;

    // Utilizando o Framebuffer do Archive
    Framebuffer framebuffer(nCol, nLin);

    // Instanciando a esfera utilizando a abstração do Archive
    Material matDummy(esfColor, esfColor, esfColor, 1.0f);
    Sphere esfera(centerEsfera, rEsfera, matDummy);

    // Loop de renderização pixel a pixel
    std::cout << "Renderizando a imagem..." << std::endl;
    for (int l = 0; l < nLin; l++) {
        for (int c = 0; c < nCol; c++) {
            
            float x = -wJanela/2.0f + Dx/2.0f + (float)c * Dx;
            float y = hJanela/2.0f - Dy/2.0f - (float)l * Dy;
            
            Vector3 dir(x, y, -dJanela);
            Ray ray(origin, dir);
            
            HitRecord rec;
            if (esfera.intersect(ray, 0.001f, 1e9f, rec)) {
                framebuffer.setPixel(c, l, esfColor);
            } else {
                framebuffer.setPixel(c, l, bgColor);
            }
        }
    }

    std::cout << "Renderização concluída. Abrindo a janela interativa com GLFW e OpenGL..." << std::endl;
    
    try {
        Display::show(framebuffer, "Tarefa 1 - Janela Interativa");
    } catch (const std::exception& e) {
        std::cerr << "\nErro ao inicializar janela: " << e.what() << "\n";
        return 1;
    }

    return 0;
}
