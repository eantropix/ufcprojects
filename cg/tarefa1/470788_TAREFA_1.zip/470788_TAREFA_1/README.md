# Tarefa 1 - Ray Tracing (CPU)
**Aluno:** Matrícula 470788

Este projeto renderiza uma esfera vermelha sobre um fundo cinza utilizando uma arquitetura básica de Ray Tracing (CPU). A exibição final é feita através de uma janela interativa nativa acelerada utilizando **OpenGL** e **GLFW**, evitando a criação de arquivos de imagem intermediários.

A estrutura do projeto foi feita importando os padrões Orientados a Objetos da base de código `Archive` fornecida.

## Requisitos do Sistema
Para que o código compile e seja executado com sucesso no Linux, é necessário ter a biblioteca **GLFW3** e o **OpenGL** instalados em seu sistema.

Para instalá-los:
- **Ubuntu/Debian:** `sudo apt install libglfw3-dev libgl1-mesa-dev`
- **Fedora:** `sudo dnf install glfw-devel mesa-libGL-devel`
- **Arch/Hyprland (Omarchy):** `sudo pacman -S glfw-wayland` (ou glfw-x11)

## Como compilar e executar

1. Abra o terminal nesta pasta (`470788_TAREFA_1`)
2. Limpe *builds* antigos e recompile utilizando o `Make`:
   ```bash
   make clean
   make
   ```
3. Execute o renderizador:
   ```bash
   ./main
   ```

A janela irá abrir com a resolução original e sem possibilidade de alteração de escala pelo próprio código.
**Aviso para Tiling Window Managers:** Se estiver utilizando *Hyprland*, *i3*, *Sway* ou semelhantes, a janela poderá ser esticada para ocupar todo o painel (16:9). Pressione o seu atalho de flutuação (floating/togglefloating) para que a janela assuma a resolução de 800x800 programada sem distorcer a imagem.
