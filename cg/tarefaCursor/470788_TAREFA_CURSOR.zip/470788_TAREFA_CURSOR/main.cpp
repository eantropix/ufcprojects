#define GL_SILENCE_DEPRECATION

#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>
#include <chrono>
#include <iomanip>

#include <GLFW/glfw3.h>

// Reutilizando as classes e abstrações do projeto
#include "header/Vector3.h"
#include "header/Ray.h"
#include "header/Sphere.h"
#include "header/Color.h"
#include "header/HitRecord.h"
#include "header/Material.h"
#include "header/PointLight.h"
#include "header/Framebuffer.h"

// Estrutura para cache de geometria fixa (observador e esfera não se movem)
struct PrecalcPixel {
    bool hit = false;
    Vector3 PI;
    Vector3 normal;
    Vector3 v_dir;
};

// Variáveis globais para callbacks GLFW
static float g_lightZ = -30.0f; // Inicialmente no plano da janela de visualização (z = -30m)
static bool g_useBlinn = false;
static bool g_saveRequested = false;

void scrollCallback(GLFWwindow* /*window*/, double /*xoffset*/, double yoffset) {
    g_lightZ += static_cast<float>(yoffset) * 2.5f;
    // O vértice frontal da esfera está em z = -60m (-100 + 40).
    // Impedimos que a luz passe para dentro da esfera
    if (g_lightZ < -58.0f) g_lightZ = -58.0f;
    if (g_lightZ > 50.0f)  g_lightZ = 50.0f;
}

void keyCallback(GLFWwindow* window, int key, int /*scancode*/, int action, int /*mods*/) {
    if (action == GLFW_PRESS) {
        if (key == GLFW_KEY_ESCAPE) {
            glfwSetWindowShouldClose(window, GLFW_TRUE);
        } else if (key == GLFW_KEY_B) {
            g_useBlinn = !g_useBlinn;
            std::cout << "[INFO] Modelo alternado para: " 
                      << (g_useBlinn ? "Blinn-Phong" : "Phong Clássico") << std::endl;
        } else if (key == GLFW_KEY_S) {
            g_saveRequested = true;
        } else if (key == GLFW_KEY_R) {
            g_lightZ = -30.0f;
            std::cout << "[INFO] Posição Z da luz restaurada para -30.0m" << std::endl;
        }
    }
}

void savePPM(const Framebuffer& fb, const std::string& filename) {
    std::ofstream out(filename);
    if (!out) {
        std::cerr << "Aviso: Não foi possível salvar o arquivo PPM: " << filename << std::endl;
        return;
    }
    out << "P3\n" << fb.width() << " " << fb.height() << "\n255\n";
    const std::uint8_t* data = fb.data();
    for (int y = 0; y < fb.height(); ++y) {
        for (int x = 0; x < fb.width(); ++x) {
            std::size_t idx = (static_cast<std::size_t>(y) * fb.width() + x) * 3;
            out << static_cast<int>(data[idx + 0]) << " "
                << static_cast<int>(data[idx + 1]) << " "
                << static_cast<int>(data[idx + 2]) << " ";
        }
        out << "\n";
    }
    std::cout << "[SNAPSHOT] Imagem salva com sucesso em: " << filename << std::endl;
}

int main() {
    std::cout << "============================================================" << std::endl;
    std::cout << "       Tarefa Cursor: Fonte de Luz Interativa (Ray Tracing) " << std::endl;
    std::cout << "============================================================" << std::endl;
    std::cout << "Controles:" << std::endl;
    std::cout << "  - [Mouse]: Mova o cursor na janela para mover a fonte de luz (X, Y)" << std::endl;
    std::cout << "  - [Scroll]: Roda do mouse ajusta a profundidade da luz (Z)" << std::endl;
    std::cout << "  - [B]: Alterna entre o modelo de Phong e Blinn-Phong" << std::endl;
    std::cout << "  - [S]: Salva um snapshot da imagem atual em 'cursor_iluminado.ppm'" << std::endl;
    std::cout << "  - [R]: Restaura Z da luz para a janela de projecao (-30m)" << std::endl;
    std::cout << "  - [ESC]: Sair" << std::endl;
    std::cout << "============================================================" << std::endl;

    // Configurações da cena herdadas da Tarefa 02
    const float wJanela = 60.0f;
    const float hJanela = 60.0f;
    const float dJanela = 30.0f;

    const Vector3 origin(0.0f, 0.0f, 0.0f);
    const float rEsfera = 40.0f;
    const Vector3 centerEsfera(0.0f, 0.0f, -100.0f);

    const Color esfColor(1.0f, 0.0f, 0.0f);
    const Color bgColor(100.0f / 255.0f, 100.0f / 255.0f, 100.0f / 255.0f);

    const int nCol = 800;
    const int nLin = 800;

    const float Dx = wJanela / static_cast<float>(nCol);
    const float Dy = hJanela / static_cast<float>(nLin);

    const Color I_F(0.7f, 0.7f, 0.7f);
    const Color K_d = esfColor;
    const Color K_e = esfColor;
    const float m_phong = 10.0f;
    const float m_blinn = 25.0f; // Equivalente visual ao m=10 no Phong

    Material mat(Color(0.0f, 0.0f, 0.0f), K_d, K_e, m_phong);
    Sphere esfera(centerEsfera, rEsfera, mat);

    Framebuffer framebuffer(nCol, nLin);

    // Pré-computação das interseções estáticas para máxima taxa de quadros (60+ FPS)
    std::cout << "Pré-calculando geometria estática..." << std::endl;
    std::vector<PrecalcPixel> cache(nCol * nLin);

    #pragma omp parallel for collapse(2) schedule(static)
    for (int l = 0; l < nLin; ++l) {
        for (int c = 0; c < nCol; ++c) {
            float x = -wJanela / 2.0f + Dx / 2.0f + static_cast<float>(c) * Dx;
            float y =  hJanela / 2.0f - Dy / 2.0f - static_cast<float>(l) * Dy;

            Vector3 dir(x, y, -dJanela);
            Ray ray(origin, dir);

            HitRecord rec;
            int idx = l * nCol + c;
            if (esfera.intersect(ray, 0.001f, 1e9f, rec)) {
                cache[idx].hit = true;
                cache[idx].PI = rec.point;
                cache[idx].normal = rec.normal.normalized();
                cache[idx].v_dir = (origin - rec.point).normalized();
            } else {
                cache[idx].hit = false;
            }
        }
    }
    std::cout << "Geometria pré-calculada com sucesso! Inicializando janela GLFW..." << std::endl;

    // Inicialização do GLFW
    if (!glfwInit()) {
        std::cerr << "Erro fatal: Não foi possível inicializar o GLFW." << std::endl;
        return 1;
    }

    // Janela redimensionável (compatível com Hyprland e Tiling WMs)
    glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

    GLFWwindow* window = glfwCreateWindow(nCol, nLin, "Tarefa Cursor - Luz Interativa", nullptr, nullptr);
    if (!window) {
        glfwTerminate();
        std::cerr << "Erro fatal: Não foi possível criar janela GLFW." << std::endl;
        return 1;
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // V-Sync

    glfwSetScrollCallback(window, scrollCallback);
    glfwSetKeyCallback(window, keyCallback);

    // Configuração OpenGL para exibição rápida
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, nCol, nLin, 0.0, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    auto lastTime = std::chrono::high_resolution_clock::now();
    int frameCount = 0;
    float currentFps = 0.0f;

    // Loop de renderização interativa em tempo real
    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        // Obtém dimensões atuais da janela e posição do cursor
        int winW, winH;
        glfwGetWindowSize(window, &winW, &winH);

        double mouseX, mouseY;
        glfwGetCursorPos(window, &mouseX, &mouseY);

        // Mapeia as coordenadas do mouse (pixels da janela) para o espaço mundial (metros)
        float normX = (winW > 0) ? static_cast<float>(mouseX) / static_cast<float>(winW) : 0.5f;
        float normY = (winH > 0) ? static_cast<float>(mouseY) / static_cast<float>(winH) : 0.5f;

        normX = std::max(0.0f, std::min(1.0f, normX));
        normY = std::max(0.0f, std::min(1.0f, normY));

        float lightX = -wJanela / 2.0f + normX * wJanela;
        float lightY =  hJanela / 2.0f - normY * hJanela;
        Vector3 lightPos(lightX, lightY, g_lightZ);

        // Renderiza o frame calculando iluminação difusa + especular com a nova posição da luz
        #pragma omp parallel for collapse(2) schedule(static)
        for (int l = 0; l < nLin; ++l) {
            for (int c = 0; c < nCol; ++c) {
                int idx = l * nCol + c;
                const auto& pix = cache[idx];

                if (!pix.hit) {
                    framebuffer.setPixel(c, l, bgColor);
                    continue;
                }

                Vector3 l_vec = lightPos - pix.PI;
                Vector3 l_dir = l_vec.normalized();
                float l_dot_n = l_dir.dot(pix.normal);

                if (l_dot_n <= 0.0f) {
                    // Ponto em auto-sombra
                    framebuffer.setPixel(c, l, Color(0.0f, 0.0f, 0.0f));
                    continue;
                }

                // Componente Difusa: I_d = (I_F @ K_d) * max(0, l . n)
                Color I_d = (I_F * K_d) * l_dot_n;
                Color I_e(0.0f, 0.0f, 0.0f);

                if (g_useBlinn) {
                    // Blinn-Phong: Halfway vector h = (l + v) / ||l + v||
                    Vector3 h = (l_dir + pix.v_dir).normalized();
                    float n_dot_h = pix.normal.dot(h);
                    if (n_dot_h > 0.0f) {
                        I_e = (I_F * K_e) * std::pow(n_dot_h, m_blinn);
                    }
                } else {
                    // Phong Clássico: Reflexão r = 2(l . n)n - l
                    Vector3 r = (2.0f * l_dot_n * pix.normal - l_dir).normalized();
                    float v_dot_r = pix.v_dir.dot(r);
                    if (v_dot_r > 0.0f) {
                        I_e = (I_F * K_e) * std::pow(v_dot_r, m_phong);
                    }
                }

                Color I_total = (I_d + I_e).clamped();
                framebuffer.setPixel(c, l, I_total);
            }
        }

        // Processa requisição de salvamento de snapshot
        if (g_saveRequested) {
            g_saveRequested = false;
            savePPM(framebuffer, "cursor_iluminado.ppm");
        }

        // Atualização de Viewport e desenho via OpenGL
        int fbW, fbH;
        glfwGetFramebufferSize(window, &fbW, &fbH);

        glViewport(0, 0, fbW, fbH);
        glClear(GL_COLOR_BUFFER_BIT);

        float scaleX = static_cast<float>(fbW) / static_cast<float>(nCol);
        float scaleY = static_cast<float>(fbH) / static_cast<float>(nLin);

        glRasterPos2i(0, 0);
        glPixelZoom(scaleX, -scaleY);
        glDrawPixels(nCol, nLin, GL_RGB, GL_UNSIGNED_BYTE, framebuffer.data());
        glPixelZoom(1.0f, 1.0f);

        glfwSwapBuffers(window);

        // Medição e exibição de FPS e parâmetros no título da janela
        frameCount++;
        auto now = std::chrono::high_resolution_clock::now();
        std::chrono::duration<float> elapsed = now - lastTime;
        if (elapsed.count() >= 0.25f) {
            currentFps = static_cast<float>(frameCount) / elapsed.count();
            frameCount = 0;
            lastTime = now;

            char titleBuf[256];
            std::snprintf(titleBuf, sizeof(titleBuf),
                "Tarefa Cursor | Luz: (X: %.1f, Y: %.1f, Z: %.1f) | Modelo: %s | FPS: %.0f",
                lightX, lightY, g_lightZ,
                g_useBlinn ? "Blinn-Phong" : "Phong",
                currentFps);
            glfwSetWindowTitle(window, titleBuf);
        }
    }

    // Finalização
    glfwDestroyWindow(window);
    glfwTerminate();
    std::cout << "Programa finalizado com sucesso." << std::endl;
    return 0;
}
