# Tarefa Cursor - Fonte de Luz Interativa em Tempo Real via Ray Tracing
**Aluno:** Matrícula 470788  
**Ambiente:** Linux (C++17, OpenMP, GLFW3, OpenGL)

Este projeto é um experimento interativo avançado baseado na **Tarefa 02**. O cursor do mouse atua diretamente como uma **fonte de luz pontual dinâmica ($P_F$)**, permitindo visualizar e explorar em tempo real como as componentes **Difusa ($I_d$)** e **Especular ($I_e$)** de Phong e Blinn-Phong respondem a variações da posição da luz.

---

## 1. Funcionamento Teórico e Mapeamento 2D -> 3D

Na **Tarefa 02**, a luz possuía uma posição fixa $P_F = (0, 5, 0)$. 

Na **Tarefa Cursor**, a posição do mouse na janela do GLFW $(x_{\text{mouse}}, y_{\text{mouse}})$ é capturada a cada instante e projetada no espaço tridimensional da cena:

### Mapeamento Matemático:
Sendo a janela de projeção definida por largura $wJanela = 60.0$, altura $hJanela = 60.0$ e distância focal $dJanela = 30.0$ ($z = -30.0$):

1. **Normalização das coordenadas da janela:**
   $$u = \frac{x_{\text{mouse}}}{W_{\text{janela}}}, \quad v = \frac{y_{\text{mouse}}}{H_{\text{janela}}}$$
   onde $u, v \in [0, 1]$.

2. **Cálculo da posição 3D da fonte de luz ($P_F$):**
   $$P_{F,x} = -\frac{wJanela}{2} + u \cdot wJanela$$
   $$P_{F,y} =  \frac{hJanela}{2} - v \cdot hJanela$$
   $$P_{F,z} = z_{\text{luz}} \quad (\text{inicialmente } -30.0 \text{ no plano da tela, ajustável pelo scroll})$$

---

## 2. Otimização para Alta Performance (60+ FPS)

O cálculo de Ray Tracing completo pixel a pixel para $800 \times 800$ (640.000 raios) pode ser custoso se recalculado do zero a cada frame. No entanto:
- O olho do observador $(0, 0, 0)$ e a esfera (centro $(0, 0, -100)$ e raio $40$) **são estáticos**.
- Logo, os raios de visão, pontos de impacto $PI$ e as normais unitárias $\vec{n}$ nunca mudam de um quadro para o outro.

**Solução implementada:**
1. **Pré-computação (Geometry Precache):** No início da aplicação, as interseções da esfera e as normais são calculadas uma única vez em memória (~5ms).
2. **Shading Paralelo em Tempo Real (OpenMP):** A cada movimentação do mouse, apenas a iluminação local (vetor de luz $\vec{l}$, $I_d$ e $I_e$) é recalculada em paralelo aproveitando todos os núcleos da CPU, alcançando taxas de quadros fluidas (60+ FPS cravados com V-Sync).

---

## 3. Comparação Dinâmica: Phong vs. Blinn-Phong

Pressionando a tecla <kbd>B</kbd>, o programa alterna instantaneamente entre:
- **Phong Clássico:** Reflexão da luz $\vec{r} = 2(\vec{l} \cdot \vec{n})\vec{n} - \vec{l}$ e termo especular $(\vec{v} \cdot \vec{r})^m$ com $m = 10$.
- **Blinn-Phong:** Vetor intermediário (*halfway*) $\vec{h} = \frac{\vec{l} + \vec{v}}{\|\vec{l} + \vec{v}\|}$ e termo especular $(\vec{n} \cdot \vec{h})^{m_{\text{Blinn}}}$ com $m_{\text{Blinn}} = 25$.

Observe como o modelo de Blinn-Phong preserva transições mais suaves nas bordas da esfera quando o mouse se desloca para as extremidades.

---

## 4. Controles Interativos

| Controle | Ação |
| :--- | :--- |
| **Mover o Mouse** | Move a fonte de luz no plano $(X, Y)$ da tela |
| **Roda do Mouse (Scroll)** | Desloca a luz no eixo $Z$ (aproxima ou afasta da esfera) |
| **Tecla B** | Alterna entre iluminação **Phong** e **Blinn-Phong** |
| **Tecla S** | Salva um snapshot da tela em `cursor_iluminado.ppm` |
| **Tecla R** | Restaura o $Z$ da luz para o plano da tela ($-30.0$) |
| **Tecla ESC** | Fecha a janela e encerra o programa |

> [!TIP]
> O título da janela é atualizado em tempo real exibindo a posição 3D atual da luz $(X, Y, Z)$, o modelo de iluminação ativo e a taxa de quadros (FPS).

---

## 5. Compatibilidade com Hyprland e Tiling WMs

A janela GLFW foi criada com suporte nativo a redimensionamento (`GLFW_RESIZABLE = GLFW_TRUE`). No **Hyprland (Omarchy)**:
- Pressione <kbd>SUPER</kbd> + <kbd>T</kbd> para alternar livremente entre modo flutuante e modo tiling.
- Use <kbd>SUPER</kbd> + **Botão Direito do Mouse** para redimensionar a janela; o renderizador ajustará o viewport e a escala automaticamente.

---

## 6. Como Compilar e Executar

1. Acesse o diretório:
   ```bash
   cd /home/eantropix/source/repos/ufcprojects/cg/tarefaCursor
   ```

2. Compile:
   ```bash
   make clean
   make
   ```

3. Execute:
   ```bash
   ./main
   ```
