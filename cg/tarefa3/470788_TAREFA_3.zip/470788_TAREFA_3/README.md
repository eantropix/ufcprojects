# Tarefa 3 - Ray Tracing com Esfera, Planos e Sombras

**Aluno:** Arthur Santos Viana de Oliveira  
**Matrícula:** 470788  
**Disciplina:** Computação Gráfica - UFC  

Este projeto é a implementação da **Tarefa 03**, estendendo a Tarefa 02 para compor uma cena tridimensional completa contendo uma **esfera**, dois **planos** (chão e fundo), uma **fonte de luz pontual**, **iluminação ambiente** e cálculo de **raios de sombra (shadow rays)** projetados pela esfera sobre as superfícies.

A imagem é renderizada via CPU por Ray Tracing e exibida em uma janela interativa nativa acelerada por GPU via **OpenGL** e **GLFW3**, além de ser salva como imagem estática em formato PPM.

---

## 1. Fundamentação Teórica e Formulação Matemática

### 1.1 Modelo de Câmera e Geração de Raios
- **Observador (Olho):** $P_0 = (0, 0, 0)$
- **Janela de Projeção:** Dimensões $W_J = 60\,\text{cm}$, $H_J = 60\,\text{cm}$ posicionada em $z = -d = -30\,\text{cm}$.
- **Canvas / Resolução:** $nCol = 500$, $nLin = 500$ pixels.
- **Tamanho da célula na grade:**
  $$Dx = \frac{W_J}{nCol} = \frac{60}{500} = 0.12\,\text{cm}, \quad Dy = \frac{H_J}{nLin} = \frac{60}{500} = 0.12\,\text{cm}$$
- **Mapeamento Pixel $(c, l)$ para o Espaço Mundial:**
  $$x = -\frac{W_J}{2} + \frac{Dx}{2} + c \cdot Dx$$
  $$y =  \frac{H_J}{2} - \frac{Dy}{2} - l \cdot Dy$$
  $$z = -d = -30\,\text{cm}$$
- **Raio de Visão:** Partindo de $P_0$ com direção $\vec{d} = (x, y, -d)$:
  $$P(t) = P_0 + t \cdot \vec{d}$$

---

### 1.2 Interseção Raio-Plano
Um plano infinito é definido por um ponto conhecido $P_{\pi}$ e um vetor normal unitário $\vec{n}$. Qualquer ponto $P$ pertencente ao plano satisfaz:
$$(P - P_{\pi}) \cdot \vec{n} = 0$$

Substituindo a equação paramétrica do raio $P(t) = P_0 + t \vec{d}$:
$$\big((P_0 + t \vec{d}) - P_{\pi}\big) \cdot \vec{n} = 0$$
$$(P_0 - P_{\pi}) \cdot \vec{n} + t (\vec{d} \cdot \vec{n}) = 0$$
$$t = \frac{(P_{\pi} - P_0) \cdot \vec{n}}{\vec{d} \cdot \vec{n}}$$

- Se $|\vec{d} \cdot \vec{n}| < 10^{-6}$, o raio é paralelo ao plano (sem interseção).
- Uma interseção só é considerada visível se $t > 0$ (no código, $t \ge t_{min} = 10^{-4}$ para estabilidade numérica).

---

### 1.3 Seleção do Ponto de Interseção Mais Próximo
A cena possui múltiplos objetos (esfera, plano do chão e plano de fundo). Para cada raio lançado através do pixel, testa-se a colisão contra todos os objetos e seleciona-se aquele com o **menor $t_i > 0$**:
$$t_{\text{hit}} = \min \{ t_i > 0 \}$$

---

### 1.4 Teste de Oclusão e Sombra (Shadow Rays)
Conforme a especificação (Obs 4), quando o ponto de interseção $PI$ estiver sobre o plano do chão ou no plano de fundo, deve-se verificar se o caminho até a fonte de luz pontual está obstruído pela esfera.

- **Vetor em direção à luz:** $\vec{l}_{vec} = P_F - PI$, com distância $d_F = \|\vec{l}_{vec}\|$ e direção unitária $\vec{l} = \frac{\vec{l}_{vec}}{d_F}$.
- **Raio de Sombra:**
  $$P(s) = (PI + \epsilon \vec{n}) + s \cdot \vec{l}$$
  Onde $\epsilon \vec{n}$ ($\epsilon = 10^{-3}$) desloca a origem ligeiramente ao longo da normal da superfície para evitar auto-interseção/artefatos numéricos.
- **Condição de Obstrução:** Se o raio de sombra interceptar a esfera no intervalo $s \in (\epsilon, d_F - \epsilon)$, o ponto está na sombra projetada pela esfera ($\text{inShadow} = \text{true}$). Nesse caso, as componentes direta difusa e especular são anuladas ($I_d = 0$, $I_e = 0$).

---

### 1.5 Modelo de Iluminação Local (Phong com Luz Ambiente)
Para cada ponto visível $PI$ com normal unitária $\vec{n}$, material $(K_a, K_d, K_e, m)$, vetor de visão $\vec{v} = \frac{P_0 - PI}{\|P_0 - PI\|}$ e vetor refletido $\vec{r} = 2(\vec{l} \cdot \vec{n})\vec{n} - \vec{l}$:

1. **Componente Ambiente:**
   $$I_a = I_A \otimes K_a$$
2. **Componente Difusa:**
   $$I_d = (I_F \otimes K_d) \cdot \max(0, \vec{l} \cdot \vec{n}) \quad (\text{se não estiver em sombra})$$
3. **Componente Especular:**
   $$I_e = (I_F \otimes K_e) \cdot (\max(0, \vec{v} \cdot \vec{r}))^m \quad (\text{se não estiver em sombra})$$
4. **Intensidade Total:**
   $$I_{total} = \text{clamp}(I_a + I_d + I_e, [0, 1])$$

Onde $\otimes$ representa o produto componente a componente (Hadamard).

---

## 2. Parâmetros da Cena Especificados

| Objeto / Elemento | Geometria / Posição | Propriedades Ópticas |
| :--- | :--- | :--- |
| **Esfera** | Centro $C = (0, 0, -100)\,\text{cm}$, Raio $R = 40\,\text{cm}$ | $K_d = K_e = K_a = (0.7, 0.2, 0.2)$, $m = 10$ |
| **Plano do Chão** | $P_{\pi} = (0, -40, 0)\,\text{cm}$, $\vec{n} = (0, 1, 0)$ | $K_d = K_a = (0.2, 0.7, 0.2)$, $K_e = (0, 0, 0)$, $m = 1$ |
| **Plano de Fundo** | $P_{\pi} = (0, 0, -200)\,\text{cm}$, $\vec{n} = (0, 0, 1)$ | $K_d = K_a = (0.3, 0.3, 0.7)$, $K_e = (0, 0, 0)$, $m = 1$ |
| **Luz Pontual** | $P_F = (0, 60, -30)\,\text{cm}$ | $I_F = (0.7, 0.7, 0.7)$ |
| **Luz Ambiente** | Global | $I_A = (0.3, 0.3, 0.3)$ |

---

## 3. Estrutura do Projeto e Isolamento de Dependências

O projeto segue estritamente a regra de **zero dependência externa de `Archive/`**, possuindo cópias e implementações locais:

```text
tarefa3/
├── specs.md                  # Especificações originais fornecidas
├── header/                   # Cabeçalhos locais (.h)
│   ├── Color.h
│   ├── Display.h
│   ├── Framebuffer.h
│   ├── HitRecord.h
│   ├── Material.h
│   ├── Object.h
│   ├── Plane.h               # Classe Plane derivada de Object
│   ├── PointLight.h
│   ├── Ray.h
│   ├── Sphere.h
│   └── Vector3.h
├── src/                      # Implementações locais (.cpp)
│   ├── Color.cpp
│   ├── Display.cpp           # Configurado com GLFW_RESIZABLE = GLFW_TRUE
│   ├── Framebuffer.cpp
│   ├── Material.cpp
│   ├── Plane.cpp             # Interseção raio-plano
│   ├── PointLight.cpp
│   ├── Ray.cpp
│   ├── Sphere.cpp
│   └── Vector3.cpp
├── main.cpp                  # Loop principal do Ray Tracer e integração
├── Makefile                  # Script de compilação autônomo
├── README.md                 # Este documento explicativo
├── tarefa3.ppm               # Imagem estática gerada na resolução 500x500
├── 470788_TAREFA_3/          # Pacote autocontido para envio
│   ├── header/
│   ├── src/
│   ├── main.cpp
│   ├── Makefile
│   └── README.md
└── 470788_TAREFA_3.zip       # Arquivo ZIP pronto para submissão no portal da UFC
```

---

## 4. Como Compilar e Executar

### Pré-requisitos:
- Compilador C++17 (`g++`)
- Bibliotecas GLFW3 e OpenGL (`-lglfw -lGL`)

### Comandos:
```bash
# 1. Entrar no diretório da tarefa
cd tarefa3

# 2. Limpar builds anteriores e compilar
make clean
make

# 3. Executar o programa
./main
```

### Controles da Janela:
- **ESC**: Encerra o programa e fecha a janela.
- **Botão Fechar da Janela**: Encerra a aplicação normalmente.
- Suporta redimensionamento dinâmico e integração completa com Tiling Window Managers (**Hyprland**, **i3**, **Sway**).
