#pragma once
#include "Object.h"

class Plane : public Object {
    Vector3 point_;
    Vector3 normal_;
    Material material_;
public:
    Plane(const Vector3& point, const Vector3& normal, const Material& material);
    bool intersect(const Ray& ray, float tMin, float tMax, HitRecord& hit) const override;
    const Vector3& point() const { return point_; }
    const Vector3& normal() const { return normal_; }
    const Material& material() const { return material_; }
};
