#include "Plane.h"
#include <cmath>

Plane::Plane(const Vector3& point, const Vector3& normal, const Material& material)
    : point_(point), normal_(normal.normalized()), material_(material) {}

bool Plane::intersect(const Ray& ray, float tMin, float tMax, HitRecord& hit) const {
    float denom = ray.direction.dot(normal_);
    // Se o raio for aproximadamente paralelo ao plano, não há interseção
    if (std::abs(denom) < 1e-6f) {
        return false;
    }

    float t = (point_ - ray.origin).dot(normal_) / denom;
    if (t < tMin || t > tMax) {
        return false;
    }

    hit.t = t;
    hit.point = ray.at(t);
    hit.normal = normal_;
    hit.material = &material_;
    hit.object = this;
    return true;
}
