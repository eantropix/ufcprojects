#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>

// Classes e abstrações locais da tarefa
#include "header/Vector3.h"
#include "header/Ray.h"
#include "header/Sphere.h"
#include "header/Plane.h"
#include "header/Color.h"
#include "header/HitRecord.h"
#include "header/Material.h"
#include "header/PointLight.h"
#include "header/Framebuffer.h"
#include "header/Display.h"

// Função auxiliar para salvar o resultado em formato PPM (P3)
void savePPM(const Framebuffer& fb, const std::string& filename) {
    std::ofstream out(filename);
    if (!out) {
        std::cerr << "Aviso: Não foi possível salvar o arquivo PPM: " << filename << std::endl;
        return;
    }
    out << "P3\n" << fb.width() << " " << fb.height() << "\n255\n";
    const std::uint8_t* data = fb.data();
    for (int y = 0; y < fb.height(); ++y) {
        for (int x = 0; x < fb.width(); ++x) {
            std::size_t idx = (static_cast<std::size_t>(y) * fb.width() + x) * 3;
            out << static_cast<int>(data[idx + 0]) << " "
                << static_cast<int>(data[idx + 1]) << " "
                << static_cast<int>(data[idx + 2]) << " ";
        }
        out << "\n";
    }
    std::cout << "Imagem salva com sucesso em: " << filename << std::endl;
}

int main() {
    // =========================================================================
    // 1. Especificações da Tarefa 03 (Geometria da Câmera / Janela de Projeção)
    // =========================================================================
    // 1) Janela de 60cm x 60cm (H_J = 60, W_J = 60)
    const float wJanela = 60.0f;
    const float hJanela = 60.0f;

    // 2) Canvas de 500 x 500 pixels (H_C = nLin = 500, W_C = nCol = 500)
    const int nCol = 500;
    const int nLin = 500;

    // 3) Coordenada z da Janela: z = -d = -30cm
    const float dJanela = 30.0f;

    // Posição do olho do observador (origem do sistema de coordenadas)
    const Vector3 origin(0.0f, 0.0f, 0.0f);

    // Dimensões de cada célula na grade de amostragem (tela de mosquito)
    const float Dx = wJanela / static_cast<float>(nCol);
    const float Dy = hJanela / static_cast<float>(nLin);

    // Framebuffer para armazenar os pixels calculados
    Framebuffer framebuffer(nCol, nLin);

    // =========================================================================
    // 2. Especificações dos Objetos da Cena
    // =========================================================================

    // 4) Esfera com raio R = 40cm e centro C = (0, 0, -100cm)
    const float rEsfera = 40.0f;
    const Vector3 centerEsfera(0.0f, 0.0f, -100.0f);

    // 5) Reflectividade da esfera: K_d = K_e = K_a = (0.7, 0.2, 0.2), Shininess = m = 10
    const Color Ka_esfera(0.7f, 0.2f, 0.2f);
    const Color Kd_esfera(0.7f, 0.2f, 0.2f);
    const Color Ke_esfera(0.7f, 0.2f, 0.2f);
    const float m_esfera = 10.0f;
    Material matEsfera(Ka_esfera, Kd_esfera, Ke_esfera, m_esfera);
    Sphere esfera(centerEsfera, rEsfera, matEsfera);

    // 6) Plano do chão: Ponto conhecido P_pi = (0, -R, 0) = (0, -40, 0), normal n_bar = (0, 1, 0)
    const Vector3 pChao(0.0f, -rEsfera, 0.0f);
    const Vector3 nChao(0.0f, 1.0f, 0.0f);

    // 7) Reflectividade do chão: K_d = K_a = (0.2, 0.7, 0.2), K_e = (0, 0, 0), Shininess = m = 1
    const Color Ka_chao(0.2f, 0.7f, 0.2f);
    const Color Kd_chao(0.2f, 0.7f, 0.2f);
    const Color Ke_chao(0.0f, 0.0f, 0.0f);
    const float m_chao = 1.0f;
    Material matChao(Ka_chao, Kd_chao, Ke_chao, m_chao);
    Plane planoChao(pChao, nChao, matChao);

    // 8) Plano de Fundo: Ponto conhecido P_pi = (0, 0, -200cm), normal n_bar = (0, 0, 1)
    const Vector3 pFundo(0.0f, 0.0f, -200.0f);
    const Vector3 nFundo(0.0f, 0.0f, 1.0f);

    // 9) Reflectividade do plano de fundo: K_d = K_a = (0.3, 0.3, 0.7), K_e = (0, 0, 0), Shininess = m = 1
    const Color Ka_fundo(0.3f, 0.3f, 0.7f);
    const Color Kd_fundo(0.3f, 0.3f, 0.7f);
    const Color Ke_fundo(0.0f, 0.0f, 0.0f);
    const float m_fundo = 1.0f;
    Material matFundo(Ka_fundo, Kd_fundo, Ke_fundo, m_fundo);
    Plane planoFundo(pFundo, nFundo, matFundo);

    // Lista de objetos da cena para cálculo do menor t_i positivo (Obs 3)
    const std::vector<const Object*> objects = { &esfera, &planoChao, &planoFundo };

    // =========================================================================
    // 3. Especificações das Fontes de Luz
    // =========================================================================

    // 10) Fonte pontual: Intensidade I_F = (0.7, 0.7, 0.7), posição P_F = (0, 60cm, -30cm)
    const Vector3 P_F(0.0f, 60.0f, -30.0f);
    const Color I_F(0.7f, 0.7f, 0.7f);
    PointLight light(P_F, I_F);

    // 11) Luz ambiente: Intensidade I_A = (0.3, 0.3, 0.3)
    const Color I_A(0.3f, 0.3f, 0.3f);

    // Cor de fundo padrão (caso algum raio não colida com nenhum objeto)
    const Color bgColor(0.0f, 0.0f, 0.0f);

    // =========================================================================
    // 4. Ray Tracing: Lançamento de raios e cálculo da iluminação
    // =========================================================================
    std::cout << "Renderizando cena com Esfera, Plano do Chao e Plano de Fundo..." << std::endl;

    for (int l = 0; l < nLin; ++l) {
        for (int c = 0; c < nCol; ++c) {
            // Coordenadas do centro da célula (c, l) no plano da janela z = -d
            float x = -wJanela / 2.0f + Dx / 2.0f + static_cast<float>(c) * Dx;
            float y =  hJanela / 2.0f - Dy / 2.0f - static_cast<float>(l) * Dy;

            // Raio partindo do olho do observador (0, 0, 0) passando pelo pixel
            Vector3 dir(x, y, -dJanela);
            Ray ray(origin, dir);

            // Obs 1 e 3: Interseção com menor t_i positivo (t > 0)
            HitRecord rec;
            bool hitAnything = false;
            float closest_t = 1e9f;

            for (const Object* obj : objects) {
                HitRecord tempRec;
                // tMin = 1e-4 garante t_i > 0 e estabilidade numérica
                if (obj->intersect(ray, 1e-4f, closest_t, tempRec)) {
                    hitAnything = true;
                    closest_t = tempRec.t;
                    rec = tempRec;
                }
            }

            if (hitAnything) {
                const Material& mat = *rec.material;
                Vector3 PI = rec.point;
                Vector3 n = rec.normal.normalized();

                // Componente Ambiente: I_a = I_A @ K_a
                Color I_a = I_A * mat.ka;

                Color I_d(0.0f, 0.0f, 0.0f);
                Color I_e(0.0f, 0.0f, 0.0f);

                // Vetor apontando de PI para a fonte de luz pontual P_F
                Vector3 l_vec = light.position() - PI;
                float distLight = l_vec.length();
                Vector3 l_dir = l_vec / distLight; // Vetor unitário l

                // Produto escalar (l . n)
                float l_dot_n = l_dir.dot(n);

                // Apenas calcula iluminação direta se a superfície estiver voltada para a luz
                if (l_dot_n > 0.0f) {
                    bool inShadow = false;

                    // Obs 4: Quando o ponto de interseção visto estiver no plano do chão ou
                    // no plano de fundo, não calcule as contribuições difusa e especular
                    // sem antes verificar se o raio P(s) = P_i + s*vetor_l está sendo obstruído pela esfera.
                    if (rec.object != &esfera) {
                        // Desloca sutilmente a origem ao longo da normal para evitar auto-oclusão
                        Ray shadowRay(PI + n * 1e-3f, l_dir);
                        HitRecord shadowRec;
                        // Verifica se há colisão com a esfera no intervalo entre o ponto e a luz
                        if (esfera.intersect(shadowRay, 1e-3f, distLight - 1e-3f, shadowRec)) {
                            inShadow = true;
                        }
                    }

                    // Se não estiver em sombra, calcula parcelas difusa e especular
                    if (!inShadow) {
                        // Parcela Difusa: I_d = (I_F @ K_d) * max(0, l . n)
                        I_d = (light.intensity() * mat.kd) * l_dot_n;

                        // Vetor unitário de visão v (de PI para o observador)
                        Vector3 v_dir = (origin - PI).normalized();

                        // Vetor unitário de reflexão r: r = 2 * (l . n) * n - l
                        Vector3 r = (2.0f * l_dot_n * n - l_dir).normalized();

                        // Produto escalar (v . r)
                        float v_dot_r = v_dir.dot(r);
                        if (v_dot_r > 0.0f) {
                            // Parcela Especular: I_e = (I_F @ K_e) * (max(0, v . r))^m
                            float specFactor = std::pow(v_dot_r, mat.shininess);
                            I_e = (light.intensity() * mat.ks) * specFactor;
                        }
                    }
                }

                // Cor final somando ambiente, difusa e especular limitada a [0, 1]
                Color I_total = (I_a + I_d + I_e).clamped();
                framebuffer.setPixel(c, l, I_total);
            } else {
                framebuffer.setPixel(c, l, bgColor);
            }
        }
    }

    std::cout << "Renderização concluída com sucesso!" << std::endl;

    // Salva arquivo PPM estático para validação
    savePPM(framebuffer, "tarefa3.ppm");
    savePPM(framebuffer, "cena_planos_esfera.ppm");

    // =========================================================================
    // 5. Exibição interativa em janela nativa via GLFW e OpenGL
    // =========================================================================
    std::cout << "Abrindo janela interativa GLFW/OpenGL (Pressione ESC ou feche a janela para sair)..." << std::endl;
    try {
        Display::show(framebuffer, "Tarefa 3 - Ray Tracing com Esfera e Planos");
    } catch (const std::exception& e) {
        std::cerr << "\nErro ao inicializar janela GLFW/OpenGL: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
