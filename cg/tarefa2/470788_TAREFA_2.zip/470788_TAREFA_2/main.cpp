#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <string>

// Classes e abstrações do projeto
#include "header/Vector3.h"
#include "header/Ray.h"
#include "header/Sphere.h"
#include "header/Color.h"
#include "header/HitRecord.h"
#include "header/Material.h"
#include "header/PointLight.h"
#include "header/Framebuffer.h"
#include "header/Display.h"

// Função auxiliar opcional para salvar o resultado em formato PPM
void savePPM(const Framebuffer& fb, const std::string& filename) {
    std::ofstream out(filename);
    if (!out) {
        std::cerr << "Aviso: Não foi possível salvar o arquivo PPM: " << filename << std::endl;
        return;
    }
    out << "P3\n" << fb.width() << " " << fb.height() << "\n255\n";
    const std::uint8_t* data = fb.data();
    for (int y = 0; y < fb.height(); ++y) {
        for (int x = 0; x < fb.width(); ++x) {
            std::size_t idx = (static_cast<std::size_t>(y) * fb.width() + x) * 3;
            out << static_cast<int>(data[idx + 0]) << " "
                << static_cast<int>(data[idx + 1]) << " "
                << static_cast<int>(data[idx + 2]) << " ";
        }
        out << "\n";
    }
    std::cout << "Imagem salva com sucesso em: " << filename << std::endl;
}

int main() {
    // =========================================================================
    // 1. Configurações herdadas da Tarefa 01
    // =========================================================================

    // Dimensões e posição da janela de projeção (em metros)
    float wJanela = 60.0f;
    float hJanela = 60.0f;
    float dJanela = 30.0f;

    // Posição do olho do observador (origem do sistema de coordenadas)
    Vector3 origin(0.0f, 0.0f, 0.0f);

    // Propriedades geométricas da esfera
    float rEsfera = 40.0f;
    Vector3 centerEsfera(0.0f, 0.0f, -100.0f);

    // Cor base da esfera da Tarefa 01: esfColor = (255, 0, 0) -> normalizado para [0, 1]
    Color esfColor(1.0f, 0.0f, 0.0f);

    // Cor de fundo: cinza bgColor = (100, 100, 100) -> normalizado para [0, 1]
    Color bgColor(100.0f / 255.0f, 100.0f / 255.0f, 100.0f / 255.0f);

    // Resolução da imagem (Canvas e tela de mosquito)
    int nCol = 800;
    int nLin = 800;

    // Dimensões de cada célula na tela de mosquito
    float Dx = wJanela / static_cast<float>(nCol);
    float Dy = hJanela / static_cast<float>(nLin);

    // Framebuffer para armazenar os pixels renderizados
    Framebuffer framebuffer(nCol, nLin);

    // =========================================================================
    // 2. Especificações da Tarefa 02: Fonte Pontual e Iluminação
    // =========================================================================

    // Intensidade da fonte pontual: I_F = (0.7, 0.7, 0.7)
    Color I_F(0.7f, 0.7f, 0.7f);

    // Posição da fonte pontual: P_F = (0, 5, 0) situando-se 5 metros acima do olho
    Vector3 P_F(0.0f, 5.0f, 0.0f);
    PointLight light(P_F, I_F);

    // Coeficiente de reflexão do material da esfera (K)
    // Conforme a especificação: I_d = (I_F @ K) * max(0, l . n) e I_e = (I_F @ K) * (max(0, v . r))^m
    Color K = esfColor; // (1.0f, 0.0f, 0.0f)
    Color K_d = K;      // Coeficiente difuso
    Color K_e = K;      // Coeficiente especular

    // Expoente de reflexão especular m (rugosidade / shininess de Phong)
    float m = 10.0f;

    // Instanciação da esfera
    Material mat(Color(0.0f, 0.0f, 0.0f), K_d, K_e, m);
    Sphere esfera(centerEsfera, rEsfera, mat);

    // =========================================================================
    // 3. Loop de renderização pixel a pixel (Ray Tracing)
    // =========================================================================
    std::cout << "Renderizando imagem com o modelo de iluminacao difusa e especular..." << std::endl;

    for (int l = 0; l < nLin; ++l) {
        for (int c = 0; c < nCol; ++c) {
            // Coordenadas do centro do retângulo (l, c) no plano da janela
            float x = -wJanela / 2.0f + Dx / 2.0f + static_cast<float>(c) * Dx;
            float y =  hJanela / 2.0f - Dy / 2.0f - static_cast<float>(l) * Dy;

            // Raio partindo do olho (0, 0, 0) em direção ao ponto (x, y, -dJanela)
            Vector3 dir(x, y, -dJanela);
            Ray ray(origin, dir);

            HitRecord rec;
            if (esfera.intersect(ray, 0.001f, 1e9f, rec)) {
                // Ponto de interseção PI
                Vector3 PI = rec.point;

                // Vetor normal unitário n à superfície da esfera em PI
                Vector3 n = rec.normal.normalized();

                // Vetor unitário l que aponta de PI para a fonte pontual P_F
                Vector3 l_vec = light.position() - PI;
                Vector3 l_dir = l_vec.normalized();

                // Vetor unitário v que aponta de PI para o olho do observador (origin)
                Vector3 v_vec = origin - PI;
                Vector3 v_dir = v_vec.normalized();

                // Produto escalar (l . n)
                float l_dot_n = l_dir.dot(n);

                Color I_d(0.0f, 0.0f, 0.0f);
                Color I_e(0.0f, 0.0f, 0.0f);

                // A luz só ilumina se o ponto estiver voltado para a fonte de luz (l . n > 0)
                if (l_dot_n > 0.0f) {
                    // Parcela Difusa: I_d = (I_F @ K) * max(0, (l . n))
                    I_d = (light.intensity() * K_d) * l_dot_n;

                    // Vetor unitário de reflexão r: r = 2 * (l . n) * n - l
                    Vector3 r = (2.0f * l_dot_n * n - l_dir).normalized();

                    // Produto escalar (v . r)
                    float v_dot_r = v_dir.dot(r);

                    if (v_dot_r > 0.0f) {
                        // Parcela Especular: I_e = (I_F @ K) * (max(0, v . r))^m
                        float specFactor = std::pow(v_dot_r, m);
                        I_e = (light.intensity() * K_e) * specFactor;
                    }
                }

                // Cor final é a soma da energia difusa e especular, limitada a [0, 1]
                Color I_total = (I_d + I_e).clamped();
                framebuffer.setPixel(c, l, I_total);
            } else {
                // Sem interseção: cor de background
                framebuffer.setPixel(c, l, bgColor);
            }
        }
    }

    std::cout << "Renderização concluída com sucesso!" << std::endl;

    // Salva uma cópia opcional em PPM
    savePPM(framebuffer, "esfera_iluminada.ppm");

    // =========================================================================
    // 4. Exibição em janela interativa com GLFW e OpenGL
    // =========================================================================
    std::cout << "Abrindo janela interativa (Pressione ESC ou feche a janela para sair)..." << std::endl;
    try {
        Display::show(framebuffer, "Tarefa 2 - Iluminacao Difusa e Especular");
    } catch (const std::exception& e) {
        std::cerr << "\nErro ao inicializar janela GLFW/OpenGL: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
